<?php 
require 'connect.php'; // connection to database
$headers = apache_request_headers();
$fighters = []; // array to store fighters
$sql = "SELECT * FROM cwroster ORDER BY name"; // query to select all fighters from database
if($result = mysqli_query($connection,$sql)){ // query to select all figthers from database
    $id = 0;
    while($row = mysqli_fetch_assoc($result)){
        $fighters[$id]['name'] = $row['name'];
        $fighters[$id]['team'] = $row['team'];
        $fighters[$id]['sex'] = $row['sex'];
        $id++;
    }
} // While loop used to add fighters to the array fighters with the rows name, team and sex
$postdata = file_get_contents("php://input");
if(isset($postdata) && !empty($postdata)){
  $request = json_decode($postdata); // decoding json data to be used in php functions
// variables used to store unique information to be used in functions
  $title1 = $request->title1;
  $title2 = $request->title2;
  $title3 = $request->title3;
  $weight1 = $request->weight1;
  $weight2 = $request->weight2;
  $weight3 = $request->weight3;
  $weight4 = $request->weight4;
  $weight5 = $request->weight5;
  $weight6 = $request->weight6;
  $weight7 = $request->weight7;
  $weight8 = $request->weight8;
  $weight9 = $request->weight9;
  $weight10 = $request->weight10;
  $weight11 = $request->weight11;
  $weight12 = $request->weight12;
  $weight13 = $request->weight13;
  $weight14 = $request->weight14;
  $weight15 = $request->weight15;
  $fighter1 = $request->fighter1;
  $fighter2 = $request->fighter2;
  $fighter3 = $request->fighter3;
  $fighter4 = $request->fighter4;
  $fighter5 = $request->fighter5;
  $fighter6 = $request->fighter6;
  $fighter7 = $request->fighter7;
  $fighter8 = $request->fighter8;
  $fighter9 = $request->fighter9;
  $fighter10 = $request->fighter10;
  $fighter11 = $request->fighter11;
  $fighter12 = $request->fighter12;
  $fighter13 = $request->fighter13;
  $fighter14 = $request->fighter14;
  $fighter15 = $request->fighter15;
  $fighter16 = $request->fighter16;
  $fighter17 = $request->fighter17;
  $fighter18 = $request->fighter18;
  $fighter19 = $request->fighter19;
  $fighter20 = $request->fighter20;
  $fighter21 = $request->fighter21;
  $fighter22 = $request->fighter22;
  $fighter23 = $request->fighter23;
  $fighter24 = $request->fighter24;
  $fighter25 = $request->fighter25;
  $fighter26 = $request->fighter26;
  $fighter27 = $request->fighter27;
  $fighter28 = $request->fighter28;
  $fighter29 = $request->fighter29;
  $fighter30 = $request->fighter30; 
    $team1 = "";
    $team2 = "";
    $team3 = "";
    $team4 = "";
    $team5 = "";
    $team6 = "";
    $team7 = "";
    $team8 = "";
    $team9 = "";
    $team10 = "";
    $team11 = "";
    $team12 = "";
    $team13 = "";
    $team14 = "";
    $team15 = "";
    $team16 = "";
    $team17 = "";
    $team18 = "";
    $team19 = "";
    $team20 = "";
    $team21 = "";
    $team22 = "";
    $team23 = "";
    $team24 = "";
    $team25 = "";
    $team26 = "";
    $team27 = "";
    $team28 = "";
    $team29 = "";
    $team30 = "";
    $sex1 = "";
    $sex2 = "";
    $sex3 = "";
    $sex4 = "";
    $sex5 = "";
    $sex6 = "";
    $sex7 = "";
    $sex8 = "";
    $sex9 = "";
    $sex10 = "";
    $sex11 = "";
    $sex12 = "";
    $sex13 = "";
    $sex14 = "";
    $sex15 = "";
    $sex16 = "";
    $sex17 = "";
    $sex18 = "";
    $sex19 = "";
    $sex20 = "";
    $sex21 = "";
    $sex22 = "";
    $sex23 = "";
    $sex24 = "";
    $sex25 = "";
    $sex26 = "";
    $sex27 = "";
    $sex28 = "";
    $sex29 = "";
    $sex30 = "";
  $eventname = $request->eventname;
  $date = $request->date;
  $additional = $request->additional;
  $email = $request->email;
$arr = array(); // array of fighters
for($i=1;$i<31;$i++) { // for loop of 30 which correlates to the number of fighters per event
    if(!is_scalar(${"fighter$i"})){ // if statement to check if the fighter is an object or an array
        $array = json_decode(json_encode(${"fighter$i"}), true); // decoding the array to make it readable to use values for email
        $key = "name"; // Selecting the key to target for information
        ${"fighter$i"} = $array[$key]; // Assigning the value from the key 'name' to the variable fighter to be used in further conditions
    }else{
        ${"fighter$i"} = ${"fighter$i"}; // Assigning the string values to a variable to be used in further conditions }
    if(array_search(${"fighter$i"}, array_column($fighters, 'name'))){ // if statement to check if fighter exists in array other wise set the team to guest
        $key = array_search(${"fighter$i"}, array_column($fighters, 'name')); // setting a key to identify the position of the fighter in the array fighters
        ${"team$i"} =  $fighters[$key]['team']; // setting the team associated with the fighter}
    else{
        ${"team$i"} = "Guest"; // setting fighters team who are not  found in the array as they are not registered to guest.}
     $arr[] = ${"fighter$i"};}
$unique = array_unique($arr); //get unique values
$duplicates = array_diff_assoc($arr, $unique); //get duplicates
$removed = array_filter($duplicates); // remove empty values          
$dupNames =  implode( " ", $removed ); // making strings of array values if present
$matchUp = array(); // array to store the matchups
    $x=2;
    for($i=1;$i<31;$i+=2){  // Gender comparison
        if(array_search(${"fighter$i"}, array_column($fighters, 'name'))){ // if statement to check if fighter exists in array of fighters drawn from database
            $firstgender = array_search(${"fighter$i"}, array_column($fighters, 'name')); //variable to store the first fighters name
            $secondgender = array_search(${"fighter$x"}, array_column($fighters, 'name'));//variable to store the second fighters name
            ${"sex$i"} =  $fighters[$firstgender]['sex'];  // variable to store the first fighters gender
            ${"sex$x"} =  $fighters[$secondgender]['sex']; // variable to store the second fighters gender
            if(${"sex$i"} != ${"sex$x"}){ // if statement to compare genders, this is used to ensure valid match ups are made
               $matchUp[] = "Genders do not match: ".${"fighter$i"}." vs ".${"fighter$x"}."\n ."; // this array stores the names of the fighters who's match up does not 
            }else{}}else{}
        $x+=2; // increments the second fighter}
   $invalidMatch =  implode( "\n", $matchUp ); // making strings of array values if present 
   if(!empty($removed)) { // checks if there are any duplicates in the match ups and informs the admin if a mistake has been made
       echo json_encode(array("message"=>"Duplicate Fighters Found = " .$dupNames));
   }else if(!empty($matchUp)){ // checks if matchs have a male  vs female fight and informs the admin of this
        echo json_encode(array("message"=>$invalidMatch));
   }else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){ // using embedded method test the email to ensure it is valid
    echo json_encode(array("message"=>"Invalid Email."));   
}else{//      Email details to be passed
            $to      = "carville-c3@ulster.ac.uk";
            $subject = "ClanWars Event Card";
                $message = "Event Name: " . $eventname . "\n" . "Event Date: " . $date . "\n" . "\n" . "MAIN EVENT " . "\n"
                . "Title Fight: " . $title1 . "\n" . "Weight " . $weight1 . " lbs " . "\n" . $fighter1 . " (" . $team1 . ")" . " Vs " . $fighter2 . " (" . $team2 . ")" . "\n" . "\n"
                . "Title Fight: " . $title2 . "\n" . "Weight " . $weight2 . " lbs " . "\n" . $fighter3 . " (" . $team3 . ")" . " Vs " . $fighter4 . " (" . $team4 . ")" . "\n" . "\n"
                . "Title Fight: " . $title3 . "\n" . "Weight " . $weight3 . " lbs " . "\n" . $fighter5 . " (" . $team5 . ")" . " Vs " . $fighter6 . " (" . $team6 . ")" . "\n" . "\n"
                . "PRELIMS " . "\n" . "Weight " . $weight4 . "lbs" . "\n" . $fighter7 . " (" . $team7 . ")" . " Vs " . $fighter8 . " (" . $team8 . ")" . "\n"
                . "Weight " . $weight5 . " lbs " . "\n" . $fighter9 . " (" . $team9 . ")" . " Vs " . $fighter10 . " (" . $team10 . ")" . "\n"
                . "Weight " . $weight6 . " lbs " . "\n" . $fighter11 . " (" . $team11 . ")" . " Vs " . $fighter12 . " (" . $team12 . ")" . "\n"
                . "Weight " . $weight7 . " lbs " . "\n" . $fighter13 . " (" . $team13 . ")" . " Vs " . $fighter14 . " (" . $team14 . ")" . "\n"
                . "Weight " . $weight8 . " lbs " . "\n" . $fighter15 . " (" . $team15 . ")" . " Vs " . $fighter16 . " (" . $team16 . ")" . "\n"
                . "Weight " . $weight9 . " lbs " . "\n" . $fighter17 . " (" . $team17 . ")" . " Vs " . $fighter18 . " (" . $team18 . ")" . "\n"
                . "Weight " . $weight10 . " lbs " . "\n" . $fighter19 . " (" . $team19 . ")" . " Vs " . $fighter20 . " (" . $team20 . ")" . "\n"
                . "Weight " . $weight11 . " lbs " . "\n" . $fighter21 . " (" . $team21 . ")" . " Vs " . $fighter22 . " (" . $team22 . ")" . "\n"
                . "Weight " . $weight12 . " lbs " . "\n" . $fighter23 . " (" . $team23 . ")" . " Vs " . $fighter24 . " (" . $team24 . ")" . "\n"
                . "Weight " . $weight13 . " lbs " . "\n" . $fighter25 . " (" . $team25 . ")" . " Vs " . $fighter26 . " (" . $team26 . ")" . "\n"
                . "Weight " . $weight14 . " lbs " . "\n" . $fighter27 . " (" . $team27 . ")" . " Vs " . $fighter28 . " (" . $team28 . ")" . "\n"
                . "Weight " . $weight15 . " lbs " . "\n" . $fighter29 . " (" . $team29 . ")" . " Vs " . $fighter30 . " (" . $team30 . ")" . "\n" . "\n"
                . "Additional Information: " . $additional . "\n" . "\n" . "ClanWarsMMA.com Northern Irelands' Leading Mixed Martial Arts Association.";
            $headers = "From: CLANWARSMMA.com \r\n";
            $headers .= "Reply-To: '$email'" . "\r\n";
            $headers .= "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $data       = array(
                    'to' => 'carville-c3@ulster.ac.uk',
                    'subject' => $subject,
                    'message' => $message,
                    'headers' => $headers );
       // code provided by uni servers to submit emails to my student account
            $url        = 'http://scmserv3.scm.ulster.ac.uk/web/B00730222/postemail.php';
            $ch         = curl_init($url);
            $postString = http_build_query($data, '', '&');
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postString);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);
            echo $response;
            http_response_code(200);
            echo json_encode(array("message"=>"Event successfully submitted."));}}else{ echo json_encode(array("message"=>"Error with contact form."));}
?>
