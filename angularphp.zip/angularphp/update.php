<?php
require 'connect.php'; // connection to database
$postdata = file_get_contents("php://input"); // variable to store post data
if (isset($postdata) && !empty($postdata)) { // checks of post data has been received
        $request     = json_decode($postdata); // decodes the received data to be editable in php
        // Variables to store user inputs
        $fid         = mysqli_real_escape_string($connection, trim($request->fid));
        $name        = mysqli_real_escape_string($connection, trim($request->name));
        $email       = mysqli_real_escape_string($connection, trim($request->email));
        $phone       = mysqli_real_escape_string($connection, trim($request->phone));
        $sex         = mysqli_real_escape_string($connection, trim($request->sex));
        $city        = mysqli_real_escape_string($connection, trim($request->city));
        $nationality = mysqli_real_escape_string($connection, trim($request->nationality));
        $team        = mysqli_real_escape_string($connection, trim($request->team));
        $age         = mysqli_real_escape_string($connection, trim($request->age));
        $level       = mysqli_real_escape_string($connection, trim($request->level));
        $weight      = mysqli_real_escape_string($connection, trim($request->weight));
        $wins        = mysqli_real_escape_string($connection, trim($request->wins));
        $losses      = mysqli_real_escape_string($connection, trim($request->losses));
        $experience  = mysqli_real_escape_string($connection, trim($request->experience));
        $medical     = mysqli_real_escape_string($connection, trim($request->medical));
        $phonelength = strlen($phone);
        if (ctype_alpha(str_replace(' ', '', $name)) === false) { // if statement to check if name is blank or just white space
                echo json_encode(array(
                        "message" => "Name contains invalid character."
                ));
        } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { // if statement to check if email is valid with embedded function
                echo json_encode(array(
                        "message" => "Email is invalid."
                ));
        } else if (!preg_match("/^[0-9]+$/", $phone)) { // if statement to check is non numeric character has been entered
                echo json_encode(array(
                        "message" => "Phone number contains invalid character."
                ));
        } else if (($phonelength < 11) || ($phonelength > 11)) { // if statement to  check is phone number is correct length
                echo json_encode(array(
                        "message" => "Phone number must be 11 characters."
                ));
        } else if (!preg_match("/^[0-9]+$/", $age)) { // if statement to check is a non numeric character has been entered in the age category
                echo json_encode(array(
                        "message" => "Age contains invalid character."
                ));
        } else if (!preg_match("/^[0-9]+$/", $wins)) { // if statement to check is a non numeric character has been entered in the wins category
                echo json_encode(array(
                        "message" => "Wins contains invalid character."
                ));
        } else if (!preg_match("/^[0-9]+$/", $losses)) { // if statement to check is a non numeric character has been entered in the losses category
                echo json_encode(array(
                        "message" => "Losses contains invalid character."
                ));
        } else {
                // query to insert the new registration made by the user once valdiation is passed
                $query = "UPDATE cwroster SET name='$name',email='$email',phone='$phone',sex='$sex',city='$city',nationality='$nationality',team='$team',age='$age',level='$level',weight='$weight',wins='$wins',losses='$losses',experience='$experience',medical='$medical' WHERE fid='$fid'";
                if (mysqli_query($connection, $query)) {
                        http_response_code(200);
                        echo json_encode(array(
                                "message" => "Fighter Successfully Updated."
                        ));
                } else {
                        echo json_encode(array(
                                "message" => "Error with update."
                        ));
                }
        }
}
?>