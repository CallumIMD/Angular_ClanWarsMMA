<?php
require 'connect.php'; // connection to database established
$headers  = apache_request_headers();
$postdata = file_get_contents("php://input");
if (isset($postdata) && !empty($postdata)) { // check for posted data
                $request         = json_decode($postdata); // decoding the data to be readable in php
                $username        = $request->username; // variables used to store the post data
                $sq1             = $request->sq1;
                $sq2             = $request->sq2;
                $password        = $request->password;
                $retypedpassword = $request->retypedpassword;
                $result          = mysqli_query($connection, "SELECT * FROM CWadmin"); //query to select all from the cwadmin table
                $data            = $result->fetch_array();
                if ($username !== $data['username']) { // if statement to check if username is correct
                                echo json_encode(array("message" => "Incorrect Username.")); }
                else if (!password_verify($sq1, $data['sq1'])) { // if statement to check if answer to sq1 question is correct
                                echo json_encode(array("message" => "Answer to secruity question 1 incorrect."));
                } else if (!password_verify($sq2, $data['sq2'])) { // if statement to check if answer to sq2 question is correct
                                echo json_encode(array("message" => "Answer to secruity question 2 incorrect."));
                } elseif ($password !== $retypedpassword) { // if statement to check is new passwords match
                                echo json_encode(array("message" => "Passwords don't match.")); } 
                                elseif ($password == $retypedpassword) {
                                $hash  = password_hash($password, PASSWORD_BCRYPT);
                                $query = "UPDATE cwadmin SET password='$hash' where username='$username'";
                                mysqli_query($connection, $query);
                                // Email details to be passed
                                $email   = "donotreply@ClanWarsMMA.com";
                                $to      = "carville-c3@ulster.ac.uk";
                                $subject = "Your Password Has Been Updated!";
                                $message = "Your password has been updated, this is a reminder of change made on your account." . "\n" . "\n" . "Your new password: " . $password . "\n" . "\n" . "If this was not you, please contact callum@cmcwebdesign.net .";
                                $headers = "From: CLANWARSMMA.com \r\n";
                                $headers .= "Reply-To: '$email'" . "\r\n";
                                $headers .= "MIME-Version: 1.0" . "\r\n";
                                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                                $data       = array(
                                                'to' => 'carville-c3@ulster.ac.uk',
                                                'subject' => $subject,
                                                'message' => $message,
                                                'headers' => $headers
                                );
                                $url        = 'http://scmserv3.scm.ulster.ac.uk/web/B00730222/postemail.php';
                                $ch         = curl_init($url);
                                $postString = http_build_query($data, '', '&');
                                curl_setopt($ch, CURLOPT_POST, 1);
                                curl_setopt($ch, CURLOPT_POSTFIELDS, $postString);
                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                $response = curl_exec($ch);
                                curl_close($ch);
                                http_response_code(200);
                                echo json_encode(array(
                                                "message" => "Successfully Updated."
                                ));}} else { echo json_encode(array( "message" => "Problem occured with password recovery."));}
?>
    