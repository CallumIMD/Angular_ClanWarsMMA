<?php
require 'connect.php';
$headers  = apache_request_headers();
$postdata = file_get_contents("php://input");
if (isset($postdata) && !empty($postdata)) { // check for post data from service
                $request     = json_decode($postdata); // decodes the data posted into a readable format for php to manipulate
                // variables to store post data
                $name        = $request->name;
                $email       = $request->email;
                $phone       = $request->phone;
                $enquiry     = $request->enquiry;
                $phonelength = strlen($phone);
                if (ctype_alpha(str_replace(' ', '', $name)) === false) { // if statement to check if the name entry is blank 
                                echo json_encode(array(
                                                "message" => "Name contains invalid character."
                                ));
                } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { // if statement to validate email with embedded function
                                echo json_encode(array(
                                                "message" => "Email is invalid."
                                ));
                } else if (!preg_match("/^[0-9]+$/", $phone)) { // if statement to check phone number for non numeric characters
                                echo json_encode(array(
                                                "message" => "Phone number contains invalid character."
                                ));
                } else if (($phonelength < 11) || ($phonelength > 11)) { // if statement to check if phone number is the appropriate length
                                echo json_encode(array(
                                                "message" => "Phone number must be 11 characters."
                                ));
                } else {
                                // Email details to be passed
                                $to      = "carville-c3@ulster.ac.uk";
                                $subject = "Contact Form Submission";
                                $message = "Name: " . $name . "\n" . "Email: " . $email . "\n" . "Phone: " . $phone . "\n" . "Enquiry: " . $enquiry;
                                $headers = "From: CLANWARSMMA.com \r\n";
                                $headers .= "Reply-To: '$email'" . "\r\n";
                                $headers .= "MIME-Version: 1.0" . "\r\n";
                                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                                $data       = array(
                                                'to' => 'carville-c3@ulster.ac.uk',
                                                'subject' => $subject,
                                                'message' => $message,
                                                'headers' => $headers
                                );
                                $url        = 'http://scmserv3.scm.ulster.ac.uk/web/B00730222/postemail.php';
                                $ch         = curl_init($url);
                                $postString = http_build_query($data, '', '&');
                                curl_setopt($ch, CURLOPT_POST, 1);
                                curl_setopt($ch, CURLOPT_POSTFIELDS, $postString);
                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                $response = curl_exec($ch);
                                curl_close($ch);
                                echo $response;
                                http_response_code(200);
                                echo json_encode(array(
                                                "message" => "Thankyou, your form has successfully sent."
                                ));
                }
} else {
                echo json_encode(array(
                                "message" => "Error with contact form."
                ));
}
?>
