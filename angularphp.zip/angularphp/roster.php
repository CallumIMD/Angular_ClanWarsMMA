<?php 
require 'connect.php'; // connect to database
error_reporting(E_ERROR);
$fighters = [];// array to store fighters
$sql = "SELECT * FROM cwroster ORDER BY name"; //  query to select all fighters from cwroster and order by name alphatbetical
if($result = mysqli_query($connection,$sql)){ // if statement to check if query is true
    $id = 0;
    while($row = mysqli_fetch_assoc($result)){ // while loop to retrieve all fighter results from database
        $fighters[$id]['FID'] = $row['FID'];
        $fighters[$id]['name'] = $row['name'];
        $fighters[$id]['email'] = $row['email'];
        $fighters[$id]['phone'] = $row['phone'];
        $fighters[$id]['sex'] = $row['sex'];
        $fighters[$id]['city'] = $row['city'];
        $fighters[$id]['nationality'] = $row['nationality'];
        $fighters[$id]['team'] = $row['team'];
        $fighters[$id]['age'] = $row['age'];
        $fighters[$id]['level'] = $row['level'];
        $fighters[$id]['weight'] = $row['weight'];
        $fighters[$id]['wins'] = $row['wins'];
        $fighters[$id]['losses'] = $row['losses'];
        $fighters[$id]['experience'] = $row['experience'];
        $fighters[$id]['medical'] = $row['medical'];
        $id++; // increments by 1 each time
    }
    echo json_encode($fighters);
}else{
    http_response_code(404);
}
?>