<?php
require 'connect.php'; // connection to database established
if ($_FILES) { // if statement to check if an img file has been received
        $file_name   = $_FILES['myFile']['name']; // variable to store image file name in database 
        $target_dir  = "profileimages/"; // setting up directory to store images
        $target_file = $target_dir . basename($_FILES["myFile"]["name"]); // assigning the image
        move_uploaded_file($_FILES["myFile"]["tmp_name"], $target_file);
        if ($file_name == "") { // if file name was not set dont do anything
        } else {
                // query to insert the new registration made by the user once valdiation is passed
                $query = "UPDATE cwadmin SET profileimg='$file_name'"; // query to store image file name in database
                if (mysqli_query($connection, $query)) { // if statement to fire query
                        http_response_code(200);
                } else {
                }
        }
}
?>