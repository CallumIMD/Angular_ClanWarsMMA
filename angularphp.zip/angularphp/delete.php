<?php
require 'connect.php'; // connection to database called
$postdata = file_get_contents("php://input");
if(isset($postdata) && !empty($postdata)){ // check for post data from service
  $request = json_decode($postdata); // decodes the data posted into a readable format for php to manipulate
// Variables to store user inputs
$fid = mysqli_real_escape_string($connection, trim($request->fid)); // variable to store the fid to identify which fighter to delete from the database
// query to insert the new registration made by the user once valdiation is passed
$query = "DELETE from cwroster WHERE fid='$fid'";
        if(mysqli_query($connection,$query)){ // if statement to verify if query was successful
            http_response_code(200);
            echo json_encode(array("message"=>"Fighter Successfully Deleted."));
        }else{
            echo json_encode(array("message"=>"Error with delete."));
        }}
?>