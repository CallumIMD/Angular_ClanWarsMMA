<?php 
require 'connect.php'; // connection to database
error_reporting(E_ERROR);
$profileimg = [];// array to store profile image details
$sql = "SELECT * FROM cwadmin"; // query to select all 
if($result = mysqli_query($connection,$sql)){ // if statement to test if query is valid
    $id = 0;
    while($row = mysqli_fetch_assoc($result)){ // retrieves img data if available
        $profileimg[$id]['profileimg'] = $row['profileimg'];}  // sets data to variable with retrieved data
    echo json_encode($profileimg); // response with json data to service.
}else{
    http_response_code(404);}
?>