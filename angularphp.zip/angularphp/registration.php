<?php
require 'connect.php'; // database connection
$postdata = file_get_contents("php://input");
if (isset($postdata) && !empty($postdata)) { // check for post data to be available
                $request     = json_decode($postdata);
                // Variables to store user inputs
                $name        = mysqli_real_escape_string($connection, trim($request->name));
                $email       = mysqli_real_escape_string($connection, trim($request->email));
                $phone       = mysqli_real_escape_string($connection, trim($request->phone));
                $sex         = mysqli_real_escape_string($connection, trim($request->sex));
                $city        = mysqli_real_escape_string($connection, trim($request->city));
                $nationality = mysqli_real_escape_string($connection, trim($request->nationality));
                $team        = mysqli_real_escape_string($connection, trim($request->team));
                $age         = mysqli_real_escape_string($connection, trim($request->age));
                $level       = mysqli_real_escape_string($connection, trim($request->level));
                $weight      = mysqli_real_escape_string($connection, trim($request->weight));
                $wins        = mysqli_real_escape_string($connection, trim($request->wins));
                $losses      = mysqli_real_escape_string($connection, trim($request->losses));
                $experience  = mysqli_real_escape_string($connection, trim($request->experience));
                $medical     = mysqli_real_escape_string($connection, trim($request->medical));
                $phonelength = strlen($phone);
                if (ctype_alpha(str_replace(' ', '', $name)) === false) { // check if name has blank entry
                                echo json_encode(array(
                                                "message" => "Name contains invalid character."
                                ));
                } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { // if statement with filter function to validate email
                                echo json_encode(array(
                                                "message" => "Email is invalid."
                                ));
                } else if (!preg_match("/^[0-9]+$/", $phone)) { // if statement to check if phone number contains a non numeric character
                                echo json_encode(array(
                                                "message" => "Phone number contains invalid character."
                                ));
                } else if (($phonelength < 11) || ($phonelength > 11)) { // if statement to check if phone number length is appropriate
                                echo json_encode(array(
                                                "message" => "Phone number must be 11 characters."
                                ));
                } else if (($sex == "male") || ($sex == "female")) { // if statement to check if sex has been set when registering
                                echo json_encode(array(
                                                "message" => "Invalid sex value."
                                ));
                } else if (!preg_match("/^[0-9]+$/", $age)) { // if statement checking if age contains only numeric characters
                                echo json_encode(array(
                                                "message" => "Age contains invalid character."
                                ));
                } else if (($level == "amatuer") || ($level == "professional")) { // if statement checking if level of fighter has been set 
                                echo json_encode(array(
                                                "message" => "Invalid fighter level value."
                                ));
                } else if (!preg_match("/^[0-9]+$/", $wins)) { // if statement checking if wins contains only numeric characters
                                echo json_encode(array(
                                                "message" => "Wins contains invalid character."
                                ));
                } else if (!preg_match("/^[0-9]+$/", $losses)) { // if statement checking if losses contains only numeric characters
                                echo json_encode(array(
                                                "message" => "Losses contains invalid character."
                                ));
                } else {
                                // query to insert the new registration made by the user once valdiation is passed
                                $query = "INSERT INTO cwroster (name, email, phone,sex,city,nationality,team,age,level,weight,wins,losses,experience,medical) VALUES ('$name', '$email', '$phone','$sex','$city','$nationality','$team','$age','$level','$weight','$wins','$losses','$experience','$medical')";
                                if (mysqli_query($connection, $query)) {
                                                http_response_code(200);
                                                echo json_encode(array(
                                                                "message" => "Thankyou for registering to ClanWars."
                                                ));
                                } else {
                                                echo json_encode(array(
                                                                "message" => "Error with registration." ));  } }}
?>