<?php
require 'connect.php'; // connection to database established
$headers  = apache_request_headers();
$postdata = file_get_contents("php://input"); // variable stores post data from service update
if (isset($postdata) && !empty($postdata)) { // if statement to check  if data has been entered and not blank
        $request         = json_decode($postdata); // function to decode the received data to be maade editable in php
        $password        = $request->password; // variables to recevie specified data
        $retypedpassword = $request->retypedpassword;
        $result          = mysqli_query($connection, "SELECT * FROM CWadmin"); // query to select data from database
        $data            = $result->fetch_array(); // variable stores the data from the query
        if ($password == "") { // check if the data is blank
                echo json_encode(array(
                        "message" => "Password Required."
                ));
        } //$password == ""
        elseif ($password !== $retypedpassword) { // if statement to check if passwords match
                echo json_encode(array(
                        "message" => "Passwords don't match."
                ));
        } //$password !== $retypepassword
                elseif ($password == $retypedpassword) { // if statement for when passwords match
                $hash  = password_hash($password, PASSWORD_BCRYPT); // BCrypt hashing alogrithm to secure password
                $query = "UPDATE cwadmin SET password='$hash'"; // insert the encrypted password into assigned row in database
                mysqli_query($connection, $query);
                // Email details to be passed
                $email   = "donotreply@ClanWarsMMA.com";
                $to      = "carville-c3@ulster.ac.uk";
                $subject = "Your Password Has Been Updated!";
                $message = "Your password has been updated, this is a reminder of changes made on your account." . "\n" . "\n" . "Your new password: " . $password . "\n" . "\n" . "If this was not you, please contact callum@cmcwebdesign.net .";
                $headers = "From: CLANWARSMMA.com \r\n";
                $headers .= "Reply-To: '$email'" . "\r\n";
                $headers .= "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                $data       = array(
                        'to' => 'carville-c3@ulster.ac.uk',
                        'subject' => $subject,
                        'message' => $message,
                        'headers' => $headers
                );
                $url        = 'http://scmserv3.scm.ulster.ac.uk/web/B00730222/postemail.php';
                $ch         = curl_init($url);
                $postString = http_build_query($data, '', '&');
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postString);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                curl_close($ch);
                http_response_code(200);
                echo json_encode(array(
                        "message" => "Successfully Updated."
                ));
        }
} else {
        echo json_encode(array(
                "message" => "Problem Occured."
        ));
}
?>
    