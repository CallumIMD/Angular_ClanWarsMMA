<?php
require 'connect.php'; // connecting to database
$token    = null; // variable assigning token
$headers  = apache_request_headers();
$postdata = file_get_contents("php://input");
if (isset($postdata) && !empty($postdata)) { // checks for post data from service
                $request  = json_decode($postdata); // decoding the post data so that it can be manipulated in php
                // starting session and relocating the admin once passed the sign in system
                $username = $request->username;
                $password = $request->password;
                $result   = $connection->query("SELECT username,password FROM cwadmin WHERE username='$username'"); // query searching for login credentials 
                if ($result->num_rows > 0) { // if statement to check if a result has been found in the database that matches the entered credentials
                                $data = $result->fetch_array();
                                //if statement to check if the login credentials are correct to refer user either to the admin page if correct or login page if incorrect
                                if (password_verify($password, $data['password'])) {
                                                http_response_code(200);
                                                echo json_encode(array(
                                                                "message" => "Successful login.",
                                                                "token" => "0898387839" )); } else {
                                                //password not correct 
                                                echo json_encode(array(
                                                                "message" => "Invalid Username or Password."
                                                ));}} else {//no mathcing username exist
                    echo json_encode(array( "message" => "Account Does Not Exist.")); }}
?>
