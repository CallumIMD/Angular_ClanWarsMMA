<?php
require 'connect.php'; // connection to database established
$headers  = apache_request_headers();
$postdata = file_get_contents("php://input"); // variable stores post data from service update
if (isset($postdata) && !empty($postdata)) { // if statement to check  if data has been entered and not blank
        $request = json_decode($postdata); // function to decode the received data to be maade editable in php
        $cw2     = $request->cw2; // variables to recevie specified data
        $url2    = $request->url2;
        $result  = mysqli_query($connection, "SELECT * FROM CWadmin"); // query to select data from database
        $data    = $result->fetch_array(); // variable stores the data from the query
        if ($cw2 == "") { // check if the data is blank
                echo json_encode(array(
                        "message" => "Title Required."
                ));
        } elseif ($url2 == "") { // check if the data is blank
                echo json_encode(array(
                        "message" => "YouTube URL Required."
                ));
        } else {
                $query = "UPDATE cwadmin SET cw2='$cw2', url2='$url2' where AID='1'"; // query to update the url link and text in the database
                mysqli_query($connection, $query); // function to fire query
                http_response_code(200);
                echo json_encode(array(
                        "message" => "Successfully Updated."
                ));
        }
} else {
        echo json_encode(array(
                "message" => "Problem Occured."
        ));
}
?>