<?php
require 'connect.php'; // connection to database established
$headers  = apache_request_headers();
$postdata = file_get_contents("php://input"); // post data stored that is received from  service
if (isset($postdata) && !empty($postdata)) { // check if post data exists and is not empty
        $request  = json_decode($postdata); // decoding the data received
        $username = $request->username; // variable to store username
        $result   = mysqli_query($connection, "SELECT * FROM CWadmin"); // query to select all data from admin table
        $data     = $result->fetch_array(); // data is fetched using fetch array
        if ($username == "") { // if statement checking it username is blank 
                echo json_encode(array(
                        "message" => "Username required."
                ));
        }
        $query = "UPDATE cwadmin SET username='$username' where AID='1'"; // update the username in the database with the selected username
        mysqli_query($connection, $query);
        // Email details to be passed
        $email   = "donotreply@ClanWarsMMA.com";
        $to      = "carville-c3@ulster.ac.uk";
        $subject = "Your Username Has Been Updated!";
        $message = "Your username has been updated, this is a reminder of changes made on your account." . "\n" . "\n" . "Your new username: " . $username . "\n" . "\n" . "If this was not you, please contact callum@cmcwebdesign.net .";
        $headers = "From: CLANWARSMMA.com \r\n";
        $headers .= "Reply-To: '$email'" . "\r\n";
        $headers .= "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $data       = array(
                'to' => 'carville-c3@ulster.ac.uk',
                'subject' => $subject,
                'message' => $message,
                'headers' => $headers
        );
        $url        = 'http://scmserv3.scm.ulster.ac.uk/web/B00730222/postemail.php';
        $ch         = curl_init($url);
        $postString = http_build_query($data, '', '&');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postString);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        http_response_code(200);
        echo json_encode(array(
                "message" => "Successfully Updated."
        ));
} else {
        echo json_encode(array(
                "message" => "Problem Occured."
        ));
}
?>
    