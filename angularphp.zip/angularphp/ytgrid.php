<?php 
require 'connect.php'; // connection to database
error_reporting(E_ERROR); // error displayed if error occurs during connection
$youtube = []; // array to store youtube item information to be used to send to url links
$sql = "SELECT * FROM cwadmin"; // query to select all the information from the database
if($result = mysqli_query($connection,$sql)){ // if query is successful perfrom while loop
    $id = 0;
    while($row = mysqli_fetch_assoc($result)){ // while loop to retrieve
        $youtube[$id]['cw1'] = $row['cw1'];
        $youtube[$id]['cw2'] = $row['cw2'];
        $youtube[$id]['cw3'] = $row['cw3'];
        $youtube[$id]['url1'] = $row['url1'];
        $youtube[$id]['url2'] = $row['url2'];
        $youtube[$id]['url3'] = $row['url3'];
    }
    echo json_encode($youtube); // response with data encoded to be read in front end code.
}else{
    http_response_code(404);
}
?>