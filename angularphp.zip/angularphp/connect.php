<?php
// Connection to database
$connection = mysqli_connect("localhost", "root", "","angularphp") or die("Could not connect: " . mysqli_error($connection));
mysqli_select_db($connection, "angularphp") or die("database will not open"); // connection to database otherwise an error message appears
?>